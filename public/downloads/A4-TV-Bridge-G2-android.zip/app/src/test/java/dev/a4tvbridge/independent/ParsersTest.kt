package dev.a4tvbridge.independent

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertThrows
import org.junit.Test

class ParsersTest {
    @Test fun localSearchStaysOnItsPrivateNetworkAndSkipsLocalAndBroadcastAddresses() {
        fun ip(value: String) = java.net.InetAddress.getByName(value) as java.net.Inet4Address
        val smallNetwork = localTvCandidates(ip("192.168.24.6"), 29)
        assertEquals(listOf("192.168.24.1", "192.168.24.2", "192.168.24.3", "192.168.24.4", "192.168.24.5"), smallNetwork)
        assertEquals(253, localTvCandidates(ip("10.1.31.2"), 16).size)
        assertTrue(localTvCandidates(ip("203.0.113.10"), 24).isEmpty())
        assertTrue(localTvCandidates(ip("127.0.0.1"), 24).isEmpty())
    }

    @Test fun acceptsPortInAddressAndIpv6() {
        assertEquals(TvAddress("192.0.2.31", 5555), TvAddress.parse(" 192.0.2.31 "))
        assertEquals(TvAddress("192.0.2.31", 8844), TvAddress.parse("192.0.2.31:8844"))
        assertEquals(TvAddress("2001:db8::1", 8844), TvAddress.parse("[2001:db8::1]:8844"))
        assertEquals(TvAddress("2001:db8::1", 5555), TvAddress.parse("2001:db8::1"))
        assertNull(TvAddress.parse("192.0.2.31:99999"))
        assertNull(TvAddress.parse("http://192.0.2.31"))
    }
    @Test fun readsDeviceCountersAndComputesDelta() {
        val sample = DeviceReading.parse("""
            __cpu
            cpu 25 1 10 60 4 0 0 0
            __memory
            MemTotal:       2048 kB
            MemAvailable:   1024 kB
            __disk
            /dev/block/dm-0 10000 7000 3000 70% /data
            __network
                lo: 9999 0 0 0 0 0 0 0 9999 0
              eth0: 120 0 0 0 0 0 0 0 340 0
             wlan0: 20 0 0 0 0 0 0 0 60 0
            __uptime
            5412.42 50.00
        """.trimIndent())
        assertEquals(50, sample.ramUsage)
        assertEquals(70, sample.diskUsage)
        assertEquals(140L, sample.received)
        assertEquals(400L, sample.transmitted)
        assertEquals(5412L, sample.uptimeSeconds)
        assertEquals(50, sample.cpuUsage(DeviceReading(cpuTotal = 80, cpuIdle = 54)))
        assertNull(sample.cpuUsage(null))
        assertNull(sample.cpuUsage(DeviceReading(cpuTotal = 900, cpuIdle = 500)))
    }

    @Test fun distinguishesUnavailableCountersFromZero() {
        val sample = DeviceReading.parse("__cpu\ncpu broken\n__network\nPermission denied")
        assertNull(sample.ramUsage)
        assertNull(sample.diskUsage)
        assertNull(sample.received)
        assertNull(sample.cpuUsage(sample))
    }

    @Test fun groupsMemoryForAndroidPssAndRssFormats() {
        val pss = parseProcessMemory("""
            Total PSS by process:
               124,078K: com.example.tv (pid 1111 / activities)
                25,000K: com.example.tv:player (pid 2222)
                12,340K: system (pid 3333)

            Total PSS by OOM adjustment:
                999,999K: example.not_a_process (pid 4444)
        """.trimIndent())
        assertEquals(listOf(ProcessMemory("com.example.tv", 149078, 2),
            ProcessMemory("system", 12340, 1)), pss)
        assertEquals(listOf(ProcessMemory("com.example.tv", 111, 2)),
            parseProcessRss("RSS NAME\n0 kernel_thread\n100 com.example.tv\n11 com.example.tv:player"))
    }

    @Test fun readsPackageRowsAndCorrespondingRemarks() {
        assertEquals(listOf(CleanupItem("com.example.suggested", "Vendor recommendations")),
            cleanupEntries("# supported model\ncom.example.suggested # Vendor recommendations\n" +
                "com.example.suggested\nthis is not a package"))
    }

    @Test fun confinesFilesToSharedStorage() {
        assertEquals("/sdcard/Movies/holiday.mkv", TvPath.child("/sdcard/Movies", "holiday.mkv"))
        assertThrows(IllegalArgumentException::class.java) { TvPath.folder("/sdcard/../data") }
        assertThrows(IllegalArgumentException::class.java) { TvPath.folder("/sdcard-other") }
        assertFalse(TvPath.validName("side/path"))
        assertEquals("'name'\"'\"'s video'", shellText("name's video"))
    }

    @Test fun parsesWifiSnapshotAndAppTrafficFormats() {
        val wifi = parseWifiSnapshot("mWifiInfo SSID: \"HomeNet\", RSSI: -54, Link speed: 866Mbps, Frequency: 5180MHz")
        assertEquals("Wi-Fi", wifi.transport)
        assertEquals(866, wifi.linkSpeedMbps)
        assertEquals(5180, wifi.frequencyMhz)
        assertEquals(-54, wifi.rssiDbm)
        assertEquals("5 GHz (5180 MHz)", wifi.bandLabel)

        val eth = parseWifiSnapshot("2: eth0: <BROADCAST,MULTICAST,UP,LOWER_UP> mtu 1500")
        assertEquals("Ethernet", eth.transport)

        val uids = parseUidPackages("package:org.smarttube.stable uid:10123\npackage:com.google.android.youtube.tv uid:10124")
        val qtaguid = parseQtaguidTraffic(
            "idx iface acct_tag_hex uid_tag_int cnt_set rx_bytes rx_packets tx_bytes tx_packets\n" +
                "1 lo 0x0 10123 0 99999 10 99999 10\n" +
                "2 wlan0 0x0 10123 0 5000 5 1000 2\n" +
                "3 wlan0 0x0 10124 0 2000 2 500 1",
            uids
        )
        assertEquals(2, qtaguid.size)
        assertEquals("Stable", qtaguid[0].label)
        assertEquals(6000L, qtaguid[0].totalBytes)

        val netstats = parseNetstatsUidTraffic(
            "ident=[{type=WIFI}] uid=10124 set=DEFAULT\n  st=1700000 rb=8000 rp=4 tb=2000 tp=2",
            uids
        )
        assertEquals(1, netstats.size)
        assertEquals("Youtube", netstats[0].label)
        assertEquals(10000L, netstats[0].totalBytes)
    }

    @Test fun resolvesAppBadgesAndThemeConfigs() {
        assertEquals("ST", AppBrandRegistry.resolve("org.smarttube.stable").monogram)
        assertEquals("JF", AppBrandRegistry.resolve("org.jellyfin.androidtv").monogram)
        assertEquals("YT", AppBrandRegistry.resolve("com.google.android.youtube.tv").monogram)
        val json = themeConfigJson(HomeThemePreset.AURORA)
        assertTrue(json.contains("\"aurora\""))
        assertTrue(json.contains("RatherAsif04"))
    }
}

plugins {
    id("com.android.application") version "9.1.1" apply false
    id("org.jetbrains.kotlin.jvm") version "2.4.0" apply false
}
